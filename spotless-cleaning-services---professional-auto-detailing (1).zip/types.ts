
export enum ServicePackage {
  SEDAN = 'Sedan Full Detail',
  SUV = 'SUV Full Detail',
  PICKUP = 'Pickup Truck Full Detail',
  CUSTOM = 'Custom Fleet Service'
}

export interface DetailingService {
  id: string;
  name: ServicePackage;
  price: string;
  duration: string;
  description: string;
  features: string[];
  image: string;
}

export interface BookingData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  carMake: string;
  carModel: string;
  service: ServicePackage;
  date: string;
  time: string;
  notes?: string;
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  content: string;
  car: string;
}
