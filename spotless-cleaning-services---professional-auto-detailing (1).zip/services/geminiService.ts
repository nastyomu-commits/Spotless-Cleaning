
import { GoogleGenAI, Type } from "@google/genai";

const API_KEY = process.env.API_KEY || '';

export const getDetailingAdvice = async (carDescription: string) => {
  if (!API_KEY) return "I'm sorry, I'm currently unable to provide advice. Please check our service menu.";

  try {
    const ai = new GoogleGenAI({ apiKey: API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are an expert car detailing consultant for "Spotless Cleaning Services". 
      A customer is describing their car's condition: "${carDescription}". 
      
      Suggest the best service package based on their vehicle type and condition:
      - Sedan Full Detail ($180): Complete interior/exterior for sedans.
      - SUV Full Detail ($200): Focused on large interiors and high-traffic SUVs.
      - Pickup Truck Full Detail ($210): Heavy duty cleaning for trucks.
      - Custom Fleet Service: For unique or exotic needs.

      Provide a professional, friendly response (approx 100 words) explaining why you recommend a specific package and what the key benefits will be for their car. Mention that we operate all over the USA.`,
    });

    return response.text || "I recommend calling us for a custom quote based on your description.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Something went wrong while analyzing your car. Our vehicle-specific detailing packages offer the best value!";
  }
};
