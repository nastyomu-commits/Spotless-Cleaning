
import { DetailingService, Review, ServicePackage } from './types';

export const SERVICES: DetailingService[] = [
  {
    id: '1',
    name: ServicePackage.SEDAN,
    price: '$180',
    duration: '3-4 Hours',
    description: 'Complete interior and exterior rejuvenation for luxury and standard sedans.',
    image: 'https://images.unsplash.com/photo-1550355291-bbee04a92027?auto=format&fit=crop&q=80&w=800',
    features: ['Full Interior Steam Clean', 'Exterior Hand Wash & Wax', 'Wheel Arch Detailing', 'Leather Conditioning', 'Window Polishing']
  },
  {
    id: '2',
    name: ServicePackage.SUV,
    price: '$200',
    duration: '4-5 Hours',
    description: 'Deep cleaning for family SUVs, focusing on high-traffic areas and cargo space.',
    image: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&q=80&w=800',
    features: ['Three-Row Vacuuming', 'Cargo Area Extraction', 'Plastic & Trim Restoration', 'High-Gloss Wax Finish', 'Odor Elimination']
  },
  {
    id: '3',
    name: ServicePackage.PICKUP,
    price: '$210',
    duration: '5-6 Hours',
    description: 'Heavy-duty cleaning for work and personal trucks, including bed cleaning.',
    image: 'https://images.unsplash.com/photo-1597739239353-50270a473397?auto=format&fit=crop&q=80&w=800',
    features: ['Truck Bed Debris Removal', 'Chassis Rinse', 'Heavy Stain Extraction', 'Engine Bay Wipe-down', 'Tire & Rim Deep Clean']
  },
  {
    id: '4',
    name: ServicePackage.CUSTOM,
    price: 'Call for Quote',
    duration: 'Varies',
    description: 'Specialized services for fleets, exotic cars, or unique detailing needs.',
    image: 'https://images.unsplash.com/photo-1599256621730-535171e28e50?auto=format&fit=crop&q=80&w=800',
    features: ['Custom Tailored Packages', 'Fleet Discounts', 'Ceramic Add-ons', 'Paint Correction', 'Priority Scheduling']
  }
];

export const REVIEWS: Review[] = [
  {
    id: 'r1',
    author: 'James Wilson',
    rating: 5,
    content: "My sedan looks better than the day I picked it up from the dealer. The attention to detail is unmatched.",
    car: 'Tesla Model 3'
  },
  {
    id: 'r2',
    author: 'Sarah Chen',
    rating: 5,
    content: "Spotless lived up to the name. My SUV was a mess from the kids, now it's like brand new!",
    car: 'Honda Pilot'
  },
  {
    id: 'r3',
    author: 'Michael Rodriguez',
    rating: 5,
    content: "The best truck detail I've had. They even got the mud out of the bed crevices and the engine bay is shining.",
    car: 'Ford F-150'
  }
];
