
import React from 'react';

const Hero: React.FC = () => {
  return (
    <div className="relative h-[85vh] flex items-center overflow-hidden bg-slate-950">
      <div className="absolute inset-0 z-0 opacity-60">
        <img
          src="https://images.unsplash.com/photo-1599256621730-535171e28e50?auto=format&fit=crop&q=80&w=2000"
          alt="Clean shiny car"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/70 to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="max-w-2xl">
          <div className="inline-flex items-center space-x-2 bg-indigo-500/10 border border-indigo-500/20 rounded-full px-3 py-1 mb-6">
            <span className="flex h-2 w-2 rounded-full bg-indigo-500 animate-pulse"></span>
            <span className="text-indigo-400 text-sm font-semibold uppercase tracking-wider">Now Available Across the USA</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold text-white leading-tight mb-6">
            Simply <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-300">Spotless.</span>
          </h1>
          <p className="text-xl text-slate-300 mb-10 leading-relaxed max-w-lg">
            Professional car detailing services delivered nationwide. We specialize in bringing the showroom shine back to your Sedan, SUV, or Pickup Truck.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <a
              href="#book"
              className="px-8 py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold text-lg shadow-xl shadow-indigo-600/25 transition-all hover:-translate-y-1 text-center"
            >
              Book My Detail
            </a>
            <a
              href="#services"
              className="px-8 py-4 bg-white/10 hover:bg-white/20 text-white border border-white/20 rounded-xl font-bold text-lg backdrop-blur-sm transition-all text-center"
            >
              View Pricing
            </a>
          </div>
          
          <div className="mt-12 flex items-center space-x-6">
            <div className="flex -space-x-3">
              {[1, 2, 3, 4].map((i) => (
                <img
                  key={i}
                  className="inline-block h-10 w-10 rounded-full ring-2 ring-slate-950"
                  src={`https://picsum.photos/100/100?random=${i}`}
                  alt="Customer"
                />
              ))}
            </div>
            <div className="text-slate-400 text-sm">
              <span className="text-white font-bold block text-base">Serving 50+ Cities</span>
              <div className="flex text-yellow-500">
                {'★★★★★'.split('').map((s, i) => <span key={i}>{s}</span>)}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
