
import React, { useState } from 'react';
import { getDetailingAdvice } from '../services/geminiService';

const AIConsultant: React.FC = () => {
  const [input, setInput] = useState('');
  const [advice, setAdvice] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleAsk = async () => {
    if (!input.trim()) return;
    setLoading(true);
    const result = await getDetailingAdvice(input);
    setAdvice(result);
    setLoading(false);
  };

  return (
    <div className="bg-slate-900 text-white rounded-3xl overflow-hidden shadow-2xl">
      <div className="p-8 md:p-12">
        <div className="flex items-center gap-3 mb-6">
          <div className="bg-indigo-500 p-2 rounded-lg">
            <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold">AI Detail Advisor</h2>
        </div>
        
        <p className="text-slate-400 mb-8 max-w-lg leading-relaxed">
          Not sure which package is right for you? Describe your car's condition (e.g., "My car has pet hair and a few coffee stains") and our AI will recommend the perfect treatment.
        </p>

        <div className="space-y-4">
          <div className="relative">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Describe your car's condition here..."
              className="w-full bg-slate-800 border-none rounded-2xl p-4 text-white placeholder-slate-500 focus:ring-2 focus:ring-indigo-500 outline-none resize-none h-32"
            />
          </div>
          
          <button
            onClick={handleAsk}
            disabled={loading || !input.trim()}
            className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-700 disabled:text-slate-500 py-3 rounded-xl font-bold transition-all"
          >
            {loading ? 'Consulting Experts...' : 'Get Recommendation'}
          </button>
        </div>

        {advice && (
          <div className="mt-8 p-6 bg-slate-800/50 border border-slate-700 rounded-2xl animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="flex items-center gap-2 mb-3 text-indigo-400 font-semibold">
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                <path d="M10 2a8 8 0 100 16 8 8 0 000-16zm3.707 9.293a1 1 0 01-1.414 0L10 8.414l-2.293 2.293a1 1 0 01-1.414-1.414l3-3a1 1 0 011.414 0l3 3a1 1 0 010 1.414z" />
              </svg>
              Our Suggestion
            </div>
            <p className="text-slate-300 leading-relaxed text-sm italic">"{advice}"</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AIConsultant;
