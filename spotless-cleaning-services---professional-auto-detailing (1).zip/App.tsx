
import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import BookingForm from './components/BookingForm';
import AIConsultant from './components/AIConsultant';
import { SERVICES, REVIEWS } from './constants';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <main>
        <Hero />

        {/* Services Section */}
        <section id="services" className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-extrabold text-slate-900 mb-4 tracking-tight">Vehicle Detailing Packages</h2>
              <p className="text-slate-600 max-w-2xl mx-auto text-lg">
                Flat-rate pricing for every vehicle type. Available in every major city across the USA.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {SERVICES.map((service) => (
                <div key={service.id} className="group relative bg-white border border-slate-100 rounded-3xl overflow-hidden hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
                  <div className="h-48 overflow-hidden relative">
                    <img src={service.image} alt={service.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                    <div className="absolute top-4 right-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-indigo-700 font-bold text-lg shadow-sm">
                      {service.price}
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-slate-900 mb-2">{service.name}</h3>
                    <p className="text-slate-500 text-sm mb-4 leading-relaxed">{service.description}</p>
                    <div className="space-y-2">
                      {service.features.map((feature, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-sm text-slate-700">
                          <svg className="w-4 h-4 text-indigo-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          {feature}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* AI & Interactive Section */}
        <section id="ai-advisor" className="py-24 bg-slate-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              <div>
                <h2 className="text-4xl font-extrabold text-slate-900 mb-6 tracking-tight">Expert Advice, Anywhere</h2>
                <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                  Spotless Cleaning Services is proud to offer our expert AI advisor to help you choose the right treatment for your vehicle, no matter where you are in the USA.
                </p>
                <ul className="space-y-4 mb-8">
                  <li className="flex items-start gap-3">
                    <div className="bg-indigo-100 text-indigo-600 p-1 rounded-md mt-1">
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                    </div>
                    <div>
                      <span className="font-bold text-slate-900 block">USA Nationwide Coverage</span>
                      <span className="text-slate-500">Service available in all 50 states through our expert network.</span>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="bg-cyan-100 text-cyan-600 p-1 rounded-md mt-1">
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04c-.653 1.259-1.026 2.688-1.026 4.198 0 5.097 3.321 9.422 7.939 10.957A11.955 11.955 0 0112 21.056a11.955 11.955 0 018.618-3.04c.653-1.259 1.026-2.688 1.026-4.198 0-5.097-3.321-9.422-7.939-10.957z" />
                      </svg>
                    </div>
                    <div>
                      <span className="font-bold text-slate-900 block">Quality Guaranteed</span>
                      <span className="text-slate-500">Consistent professional results in every zip code.</span>
                    </div>
                  </li>
                </ul>
              </div>
              <AIConsultant />
            </div>
          </div>
        </section>

        {/* Gallery Preview */}
        <section id="gallery" className="py-24 bg-white overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-4xl font-extrabold text-slate-900 mb-12 tracking-tight text-center">National Portfolio</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                'https://images.unsplash.com/photo-1542281286-9e0a16bb7366?auto=format&fit=crop&q=80&w=800',
                'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&q=80&w=800',
                'https://images.unsplash.com/photo-1597739239353-50270a473397?auto=format&fit=crop&q=80&w=800',
                'https://images.unsplash.com/photo-1550355291-bbee04a92027?auto=format&fit=crop&q=80&w=800',
              ].map((img, i) => (
                <div key={i} className="aspect-square rounded-2xl overflow-hidden shadow-lg group">
                  <img src={img} alt="Detailing showcase" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section id="reviews" className="py-24 bg-slate-900 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-4xl font-extrabold mb-16 tracking-tight text-center">Verified Client Feedback</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {REVIEWS.map((review) => (
                <div key={review.id} className="bg-slate-800 p-8 rounded-3xl border border-slate-700">
                  <div className="flex text-yellow-500 mb-4 text-sm">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <span key={i}>{i < review.rating ? '★' : '☆'}</span>
                    ))}
                  </div>
                  <p className="text-slate-300 italic mb-6 leading-relaxed">"{review.content}"</p>
                  <div>
                    <span className="font-bold text-white block">{review.author}</span>
                    <span className="text-indigo-400 text-sm">{review.car} Owner</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Booking Section */}
        <section id="book" className="py-24 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-slate-50 rounded-[2.5rem] p-8 md:p-16 border border-slate-100 shadow-xl shadow-slate-200/50">
              <div className="text-center mb-12">
                <span className="text-indigo-600 font-bold uppercase tracking-widest text-sm mb-2 block">Booking</span>
                <h2 className="text-4xl font-extrabold text-slate-900 mb-4">Request a Service</h2>
                <p className="text-slate-500">Choose your vehicle type and find a time that works for you.</p>
              </div>
              <BookingForm />
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-slate-950 text-slate-400 py-12 border-t border-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center gap-2 mb-6">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
               <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
              </svg>
            </div>
            <span className="text-xl font-bold text-white tracking-tight">Spotless<span className="text-indigo-400">Cleaning</span></span>
          </div>
          <p className="mb-4">Available Nationwide Across the USA</p>
          <p className="mb-8">Support available 24/7 via AI Advisor | 1-800-SPOTLESS</p>
          <div className="flex justify-center space-x-6 mb-8">
            {['Instagram', 'Twitter', 'LinkedIn', 'TikTok'].map((social) => (
              <a key={social} href="#" className="hover:text-white transition-colors uppercase text-xs font-bold tracking-widest">{social}</a>
            ))}
          </div>
          <p className="text-sm">© {new Date().getFullYear()} Spotless Cleaning Services. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;
